from flask import Flask, render_template, request, jsonify      
import time
import sys
sys.path.insert(0, 'functions')
from runCalc import run_Calc
from flask import send_from_directory
import os
path = os.getcwd()

app = Flask(__name__)
exportName={}
@app.route("/")
def main():
    return render_template('home.html', reload = time.time())

@app.route("/api")
def add():
    material = request.args.get('material')
    material2 = request.args.get('material2')
    filtrado = request.args.get('filtrado')
    length = float(request.args.get('length'))
    height = float(request.args.get('height'))
    thickness = float(request.args.get('thickness'))
    thickness2 = float(request.args.get('thickness2'))
    layer = request.args.get('layer')

    
    
    rc,rd,rs,ri,freq,export=run_Calc(filtrado,length,height,thickness,material,layer,thickness2,material2)


    exportName['exportName']=export

    N = [None] * len(freq)
    for i in range (0,len(freq)):
        N[i]=i

    return jsonify({
        "rc"        :  rc,
        "rd"        :  rd,
        "rs"        :  rs,
        "ri"        :  ri,
        "freq"      :  freq,
        "N"         :  N,


    })

@app.route('/export-file/') 
def plot_csv():

    return send_from_directory(directory='export', filename=exportName['exportName']+'.xlsx', as_attachment=True)

                     
if __name__ == "__main__":
    app.run(debug=True)