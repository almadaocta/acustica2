$(function() {
    var layer=false;
    $(document).ready(function() {
        graphdiv=document.getElementById('graph');
        var data1 = [];
        var layout = {
            xaxis: {
                title: {
                    text: 'Frecuencia [Hz]',
                    font: {
                      family: 'monospace',
                      size: 18,
                      color: '#212121'
                    }
                },
            },
            yaxis:{
                title: {
                    text: 'R [Db]',
                    font: {
                      family: 'monospace',
                      size: 18,
                      color: '#212121'
                    }
                },
            },
            paper_bgcolor: "rgba(250,250,250, 0.8)",
            plot_bgcolor: "rgba(250,250,250, 0.8)",
            showlegend: true,
            hovermode: false
        }
        Plotly.newPlot(graphdiv,data1,layout);
    });
    $('.addLayer').click(function() { 

        $('.layerM').css('display','flex');
        $('.addLayer').css('display','none')
        layer=true;

    });
    $('#calc').click(function() {
        
        if ((!document.getElementById('length').value) || (!document.getElementById('height').value) || (!document.getElementById('thickness').value)){
            $('.error2').css('display','none');
            $('.error1').css('display','initial');
        }
        else if ((document.getElementById('length').value <= 0) || (document.getElementById('height').value <= 0) || (document.getElementById('thickness').value <= 0)){
            $('.error1').css('display','none');
            $('.error2').css('display','initial');
        }
        else{
            $(".disabled").removeClass('disabled');
        $.ajax({
            url : '/api',
            data: {
                "material":document.getElementById('material').value,
                "filtrado":document.getElementById('filtrado').value,
                "length":document.getElementById('length').value,
                "height":document.getElementById('height').value,
                "thickness":document.getElementById('thickness').value,
                "material2":document.getElementById('material2').value,
                "thickness2":document.getElementById('thickness2').value,
                "layer":layer
            },
            success: function(data) {

                rc=data['rc'];
                rs=data['rs'];
                ri=data['ri'];
                rd=data['rd'];
                davy=document.getElementById('davy').checked;
                cremer=document.getElementById('cremer').checked;
                iso=document.getElementById('iso').checked;
                sharp=document.getElementById('sharp').checked;
                freq=data['freq'];
                N=data['N'];
                var data = [];
                var trace1 = {
                    x: N,
                    y: rc,
                    name: 'Cremer',
                    type: 'scatter',
                    line: {
                        color: 'rgb(245, 0, 87)',
                    }
                };
                var trace2 = {
                    x: N,
                    y: rd,
                    name: 'Davy',
                    type: 'scatter',
                    line: {
                        color: 'rgb(101, 31, 255)',
                    }
                };
                var trace3 = {
                    x: N,
                    y: rs,
                    name: 'Sharp',
                    type: 'scatter',
                    line: {
                        color: 'rgb(0, 230, 118)',
                    }
                };
                var trace4 = {
                    x: N,
                    y: ri,
                    name: 'Iso',
                    type: 'scatter',
                    line: {
                        color: 'rgb(255, 196, 0)',
                    }
                };                
                if (cremer){
                    data.push(trace1);
                }
                if (davy){
                    data.push(trace2);
                }
                if (sharp){
                    data.push(trace3);
                }
                if (iso){    
                    data.push(trace4);
                }
                console.log(data);
                console.log(sharp);
                
                graphdiv=document.getElementById('graph');
                var layout = {
                    xaxis: {
                        tickmode: "array",
                        tickvals: N,
                        ticktext: freq,
                        title: {
                            text: 'Frecuencia [Hz]',
                            font: {
                              family: 'monospace',
                              size: 18,
                              color: '#212121'
                            }
                        },
                    },
                    yaxis:{
                        title: {
                            text: 'R [Db]',
                            font: {
                              family: 'monospace',
                              size: 18,
                              color: '#212121'
                            }
                        },
                    },
                    paper_bgcolor: "rgba(250,250,250, 0.8)",
                    plot_bgcolor: "rgba(250,250,250, 0.8)",
                    showlegend: true,
                    hovermode: false
                }

                Plotly.newPlot(graphdiv, data,layout);

            }
        });


        }



        
    });
})