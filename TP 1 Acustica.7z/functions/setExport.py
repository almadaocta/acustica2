from openpyxl import load_workbook
import openpyxl
import tkinter as tk
from tkinter import *
from os.path import dirname, abspath
from saveExport import export_save
from openpyxl.chart import Reference, Series, LineChart

export={}
def set_export(calcData,Rd,Rs,Rc,Ri):

    f=calcData['filterVector'] 
    material=calcData['material']
    thickness=calcData['thickness']
    height=calcData['height']
    lenght=calcData['length']
    Fc=calcData['Fc']

    export['file'] = load_workbook(filename = 'resources/sheets/exportTemplate.xlsx')
    ws = export['file'].active 
    ws.cell(row = 2, column = 1).value = material
    ws.cell(row = 2, column = 2).value = lenght
    ws.cell(row = 2, column = 3).value = height
    ws.cell(row = 2, column = 4).value = thickness
    ws.cell(row = 2, column = 5).value = Fc
    for i in range(0, len(calcData['filterVector'])):
         ws.cell(row = 4, column = i+2).value = f[i]
    for i in range(0, len(calcData['filterVector'])):
        ws.cell(row = 5, column = i+2).value = Rc[i]   
        ws.cell(row = 6, column = i+2).value = Rs[i]
        ws.cell(row = 7, column = i+2).value = Rd[i]
        ws.cell(row = 8, column = i+2).value = Ri[i]     

    #Graph

    chart = LineChart()
    chart.title = 'TL'
    maxCol=len(f)+2
    xAxis = Reference(ws,min_col=2, min_row=4, max_col=maxCol, max_row=4)
    # Cremer
    values = Reference(ws,min_col=1, min_row=5, max_col=maxCol, max_row=5)
    series = Series(values,title_from_data=True)
    chart.append(series)
    # Sharp
    values = Reference(ws,min_col=1, min_row=6, max_col=maxCol, max_row=6)
    series = Series(values,title_from_data=True)
    chart.append(series)
    # Davy
    values = Reference(ws,min_col=1, min_row=7, max_col=maxCol, max_row=7)
    series = Series(values,title_from_data=True)
    chart.append(series)
    # ISO
    values = Reference(ws,min_col=1, min_row=8, max_col=maxCol, max_row=8)
    series = Series(values,title_from_data=True)
    chart.append(series)

    chart.set_categories(xAxis)
    chart.height = 15 # default is 7.5
    chart.width = 25 # default is 15
    chart.x_axis.title = 'f[Hz]'
    chart.y_axis.title = 'Db'
    ws.add_chart(chart, 'A10') 
    

    name=export_save(export)

    return name

