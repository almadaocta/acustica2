from math import *
import math
import pandas as pd
import numpy as np

def run_sharp(calcData) :

    fVector=calcData['filterVector']
    nint=calcData['lossFactor']
    m=calcData['sd']
    Fc=calcData['Fc']
    p0=calcData['p0']
    c=calcData['c']


    R = [None] * len(fVector)

    for i in range(len(fVector)):
        
        f = fVector[i]
        Ntot=nint + (m/(485*sqrt(f)))
        if f<(0.5*Fc):
            R[i]=10*log10(1+((pi*m*f)/(p0*c))**2) - 5.5
        if f>=Fc:
            R1=10*log10(1+((pi*m*f)/(p0*c))**2) + 10*log10((Ntot*2*f)/(pi*Fc))
            R2=10*log10(1+((pi*m*f)/(p0*c))**2) - 5.5

            if R1<R2:
                R[i]=R1
            if R2<R1:
                R[i]=R2
            if R2==R1:
                R[i]=R1          
    
    #Interpolacion linear / Auxiliares
    for i in range(len(R)):
        if not R[i]:
            xStart=int(Fc/2)
            xEnd=int(Fc)
            Ntot=nint + (m/(485*sqrt(xStart)))
            yEndA=10*log10(1+((pi*m*xEnd)/(p0*c))**2) + 10*log10((Ntot*2*xEnd)/(pi*Fc))
            yEndB=10*log10(1+((pi*m*xEnd)/(p0*c))**2) - 5.5
            if yEndA<=yEndB:
                yEnd=yEndA
            if yEndA>yEndB:
                yEnd=yEndB
            yStart=10*log10(1+((pi*m*xStart)/(p0*c))**2) - 5.5
            auxL=xEnd-xStart
            fAux=[None] * (auxL+1)
            rAux=[None] * (auxL+1)

            for i in range(0,len(fAux)):
                if i==0:
                    fAux[i]=xStart
                    rAux[i]=round(yStart,2)
                else:        
                    fAux[i]=fAux[i-1]+1
            rAux[auxL]=round(yEnd,2)

            s=pd.Series(rAux)
            
            sharpNew=s.interpolate(method='linear')
            sList=sharpNew.values.tolist()
            for i in range(len(R)):
                if not R[i]:
                    fPos=int(fVector[i])
                    for o in range(len(fAux)):
                        if fAux[o]==fPos:
                            R[i]=sList[o]
            break                    
  
    
    return R        