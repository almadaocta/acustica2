def sharp_aux(sharpR,calcData):
    #for i in range(len(sharpR)):
    #    if not sharpR[i]:
    #        if sharpR[i-1] and  not sharpR[i+1]:
    #            start=calcData[i-1]
    #        if sharpR[i+1]:
    #            end=calcData[i+1]

    end=calcData('Fc') 
    start=end/2

    
    
               